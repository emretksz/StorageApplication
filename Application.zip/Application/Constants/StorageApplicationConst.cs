﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Constants
{
    public  class StorageApplicationConst
    {
        public  enum  Weight
        {
           //0-20
           first, 
           //20-40
           second,
           //40-60
           third,
           //80-100
           fourth,

        }

        public enum Amount
        {
            //1-100
            A1,
            //101-200
            A2,
            //201-300
            A3,
            //301-400
            A4,

        }
       
       
    }
}
