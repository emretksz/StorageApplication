﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Enums
{
   public class Enums
    {

        public enum PyhsicalWeight
        {
            Yol=1,//
            Orman=2,
            Dag=3,
            Su=4,
        }

       public enum TypeWeight
        {
            Koruluk=1,
            Tarim=2,
            Calilik=3,
            Gol=4,
            Akarsu=5,
        }
    }
   
}
