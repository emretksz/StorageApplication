﻿using Entities.Concrete;
using Entities.Dtos;

namespace StorageApplication.Helpers
{
    public class ScopeFunction
    {

        public double GetFirstFunction(List<LogModel> model)
        {

            return 0;
        } 
        public double GetSecondFunction(LogAndStateDto model)
        {

            return 0;
        }
    }

}
