﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DataAccess.Migrations
{
    public partial class addTables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "LogModels",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AracId = table.Column<int>(type: "int", nullable: true),
                    UrunId = table.Column<int>(type: "int", nullable: true),
                    UrunAdi = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UrunMiktarı = table.Column<int>(type: "int", nullable: true),
                    AracKapasitesi = table.Column<int>(type: "int", nullable: true),
                    DepoId = table.Column<int>(type: "int", nullable: true),
                    DepoSiparisOncesiMiktar = table.Column<int>(type: "int", nullable: true),
                    DepoSiparisSonrasiMiktar = table.Column<int>(type: "int", nullable: true),
                    IslemZamani = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Konum = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    YolculukSuresi = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Agirlik = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LogModels", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LogModels");
        }
    }
}
